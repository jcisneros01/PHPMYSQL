<?php


   DEFINE('DB_USERNAME', 'cisnejos-db');
  DEFINE('DB_PASSWORD', 'wLmxONHwRT89Qj1m');
  DEFINE('DB_HOST', 'oniddb.cws.oregonstate.edu');
  DEFINE('DB_DATABASE', 'cisnejos-db');

  $mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

  if (mysqli_connect_error()) {
    die('Connect Error ('.mysqli_connect_errno().') '.mysqli_connect_error());
  }

  // echo 'Connected successfully.';

if(!($stmt = $mysqli->prepare('DELETE FROM studentcourse WHERE studentId = ? AND courseId = ?'
))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!($stmt->bind_param("ii",$_GET['studentId'], $_GET['courseId']))){
	echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
   header("Location: university.php"); 
   exit;
}
?>

